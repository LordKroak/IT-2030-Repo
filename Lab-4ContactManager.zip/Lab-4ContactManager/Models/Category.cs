﻿namespace ContactList.Models
{
    public class Category
    {
        public string CategoryId { get; set; }
        public string CatName { get; set; }
    }
}